import tkinter as tk
import fnmatch
import os
from pygame import mixer # pygame의 mixer에서 sound 기능을 제공
mixer.init()

############################# 캔버스 #############################
canvas = tk.Tk() # tkinter-윈도우 창 생성
canvas.title("Music player")
canvas.geometry("600x800") # 가로x세로+x좌표+y좌표
canvas.config(bg = 'black') # 위젯의 속성 변경 
##################################################################



################################################# 음악 리스트 #####################################################
#리스트박스 생성
listBox = tk.Listbox(canvas, fg = "cyan", bg = "black", width = 100, font = (14)) #글꼴설정 font=('글꼴명', 사이즈)
# 테두리 생성
listBox.pack(padx = 15, pady = 15)  
##################################################################################################################




############################## 파일 가져오기 ##################################
# 파일 경로 설정
rootpath = "C:\\Users\\a1675\\OneDrive\\바탕 화면\\파이썬\\NewJeans_music" 

for root, dirs, files in os.walk(rootpath): 
# os.walk 시작 디렉터리부터 하위 모든 디렉터리 검색
    for filename in fnmatch.filter(files, '*.mp3'):
        # filter함수를 사용하여 .mp3로 끝나는 형식을 가진 모든 files들을 가져오기
        listBox.insert('end', filename)
        # 리스트의 마지막 부분에 파일 추가

###############################################################################




################################## 노래 선택 및 버튼 기능 구현 ##################################
# 선택한 음악 제목 띄우기
label = tk.Label(canvas, text = '', bg = 'black', fg = 'yellow', font = (18))
label.pack(pady = 15)

# 노래 재생
def select():
    label.config(text = listBox.get("anchor")) # anchor : 현재 선택된 항목 
    mixer.music.load(rootpath + "\\" + listBox.get("anchor")) # 노래 파일 가져오기 
    mixer.music.play()

# 노래 정지
def stop():
    mixer.music.stop()
    listBox.select_clear('active') # 선택 해제('현재 활성화 된 항목')

# 다음 노래 
def play_next():
    next_song = listBox.curselection() # 사용자가 현재 선택한 항목의 인덱스를 튜플로 반환
    next_song = next_song[0] + 1
    next_song_name = listBox.get(next_song)
    label.config(text = next_song_name)

    listBox.select_clear(0, 'end') # 리스트박스 모든 항목 선택 해제
    listBox.activate(next_song) # 다음 곡 활성화
    listBox.select_set(next_song) # 다음 곡 선택 

    mixer.music.load(rootpath + "\\" + next_song_name)
    mixer.music.play()


# 이전 노래 
def play_prev():
    next_song = listBox.curselection()
    next_song = next_song[0] - 1
    next_song_name = listBox.get(next_song)
    label.config(text = next_song_name)

    mixer.music.load(rootpath + "\\" + next_song_name)
    mixer.music.play()
    
    listBox.select_clear(0, 'end')
    listBox.activate(next_song)
    listBox.select_set(next_song)

#일시 정지
def pause_song():
    if pauseButton["text"] == "Pause":
        mixer.music.pause()
        pauseButton["text"] = "Play"
    else:
        mixer.music.unpause()
        pauseButton["text"] = "Pause"
##################################################################################################




####################### 버튼 ###########################
#버튼들 들어갈 프레임 생성 
top = tk.Frame(canvas, bg = "black")
top.pack(padx = 10, pady = 5, anchor = 'center')

#버튼 이미지 추가
prev_img = tk.PhotoImage(file = "prev_img.png")
stop_img = tk.PhotoImage(file = "stop_img.png")
play_img = tk.PhotoImage(file = "play_img.png")
pause_img = tk.PhotoImage(file = "pause_img.png")
next_img = tk.PhotoImage(file = "next_img.png")

#이전 버튼 
prevButton = tk.Button(canvas, text = "Prev", image = prev_img, bg = 'black', borderwidth = 0, command = play_prev)
prevButton.pack(pady = 15, in_ = top, side = 'left') 

#정지 버튼
stopButton = tk.Button(canvas, text = "Stop", image = stop_img, bg = 'black', borderwidth = 0, command = stop)
stopButton.pack(pady = 15, in_ = top, side = 'left')

#재생 버튼
playButton = tk.Button(canvas, text = "Play", image = play_img, bg = 'black', borderwidth = 0, command = select)
playButton.pack(pady = 15, in_ = top, side = 'left')

#일시정지 버튼 
pauseButton = tk.Button(canvas, text = "Pause", image = pause_img, bg = 'black', borderwidth = 0, command = pause_song)
pauseButton.pack(pady = 15, in_ = top, side = 'left')

#다음 버튼 
nextButton = tk.Button(canvas, text = "Next", image = next_img, bg = 'black', borderwidth = 0, command = play_next)
nextButton.pack(pady = 15, in_ = top, side = 'left')
##############################################################



canvas.mainloop()